package entity;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

import centro.GamePanel;
import centro.UtilityTool;

public class Entity {
   GamePanel gp;
   public int worldX, worldY;
   public int speed;

   public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;
   public String direction;

   public int spriteCounter = 0;
   public int spriteNum=1;

   public Rectangle solidArea = new Rectangle(0,0,48,48);
   public boolean collisionOn = false;

   public int solidAreaDefaultX;
   public int solidAreaDefaultY;

   public int actionLockCounter = 0;
   String dialogues[] = new String[50];
   int dialogueIndex=0;
   
   public Entity(GamePanel gp){
        this.gp = gp;
   } 

   public void speak(){
      if(dialogues[dialogueIndex]==null){
         dialogueIndex=0;
      }
      gp.ui.currentDialogue = dialogues[dialogueIndex];
      dialogueIndex++;

      switch (gp.player.direction) {
         case "up":
            direction="down";
               break;
         case "down":
            direction="up";
            break;
         case"right":
            direction="left";
            break;
         case"left":
            direction="right";
         default:
            break;
        }
   }

   public void setAction(){}
   
   public void update(){
      setAction();

      collisionOn=false;//CHECAR POSSIVEL CHEGAR PERTO E APARECER CONVERSA
      gp.cChecker.checkTile(this);
      gp.cChecker.checkObject(this, false);
      gp.cChecker.checkPlayer(this);


         spriteCounter++;
         if(spriteCounter>10){
             if(spriteNum==1){
                 spriteNum=2;
             }else if(spriteNum==2){
                 spriteNum=1;
             }
               spriteCounter=0;
         }

   }
   public void draw(Graphics2D g2){
        int screenX= worldX - gp.player.worldX + gp.player.screenX;
        int screenY= worldY - gp.player.worldY + gp.player.screenY;
        
        BufferedImage image = null;

        if(worldX > gp.player.worldX - gp.player.screenX - gp.tileSize &&
           worldX < gp.player.worldX + gp.player.screenX + gp.tileSize &&
           worldY > gp.player.worldY - gp.player.screenY - gp.tileSize &&
           worldY < gp.player.worldY + gp.player.screenY + gp.tileSize) {

           switch (direction) {
               case "up":
                  if(spriteNum==1){
                     image=up1;
                  }
                  if(spriteNum==2){
                     image=up2;
                  }
                  break;
               case"down":
                  if(spriteNum==1){
                     image=down1;
                  }
                  if(spriteNum==2){
                     image=down2;
                  }
                  break;
               case"left":
                  if(spriteNum==1){
                        image=left1;
                     }
                     if(spriteNum==2){
                        image=left2;
                     }
                     break;
               case"right":
                  if(spriteNum==1){
                     image=right1;
                  }
                  if(spriteNum==2){
                     image=right2;
                  }
                  break;
               }   
                  g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
            }

    }
    public BufferedImage setup(String imagePath){
            
      UtilityTool uTool = new UtilityTool();
      BufferedImage image = null;

      try{
         image = ImageIO.read(getClass().getResourceAsStream(imagePath + ".png"));
         image = uTool.scaleImage(image, gp.tileSize, gp.tileSize);

      }catch(IOException e){
          e.printStackTrace();
      }
       return image;
   }

    
    
}
